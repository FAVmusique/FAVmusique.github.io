A Pen created at CodePen.io. You can find this one at http://codepen.io/juliangarnier/pen/idhuG.

 Github repo : https://github.com/juliangarnier/3D-CSS-Solar-System
Works better in webkit, buggy in FF, flat in IE. 
Inspired by http://neography.com/experiment/circles/solarsystem/ and http://nicolasgallagher.com/css-pseudo-element-solar-system/demo/
[update] Added some basic responsive styles
