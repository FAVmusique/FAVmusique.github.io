# Solar System in WebGL with Three.js

Open index.html, nothing is required, only a WebGL browser capable.

by Strzelewicz Alexandre

# Demo

[Here #1](http://alexandre-strzelewicz.github.com/WebGL-solar-system/)
[Here #2](http://htmlpreview.github.com/?https://github.com/Alexandre-Strzelewicz/WebGL-solar-system/blob/master/index.html)

